See [Github releases](https://github.com/cyrilgdn/terraform-provider-postgresql/releases/)
